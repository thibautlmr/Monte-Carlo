#include "Model.hpp"

Model::Model(int brownianSize, double r)
  : m_brownianSize(2)
  , m_r(r)
{}