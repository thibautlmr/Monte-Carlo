// vim: set sw=4 ts=4 sts=4:
#include <iostream>
#include <cmath>
#include "BSScheme.hpp"

BSScheme::BSScheme(double maturity, double volatility, double interest_rate, double spot)
    : m_maturity(maturity), m_volatility(volatility), m_interest_rate(interest_rate),
    m_spot(spot)
{}

void BSScheme::simulExact(PnlVect *path, const PnlVect *G, int n) const
{
    pnl_vect_resize(path, n + 1);
    LET(path, 0) = m_spot;

}

BSEuler::BSEuler(double maturity, double volatility, double interest_rate, double spot)
    : BSScheme(maturity, volatility, interest_rate, spot)
{}


void BSEuler::simul(PnlVect *path, const PnlVect *G, int n) const
{
    pnl_vect_resize(path, n + 1);
    LET(path, 0) = m_spot;

}

BSMilshtein::BSMilshtein(double maturity, double volatility, double interest_rate, double spot)
    : BSScheme(maturity, volatility, interest_rate, spot)
{}


void BSMilshtein::simul(PnlVect *path, const PnlVect *G, int n) const
{
    pnl_vect_resize(path, n + 1);
    LET(path, 0) = m_spot;

}

