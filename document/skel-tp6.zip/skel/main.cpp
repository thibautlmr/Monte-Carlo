// vim: set sw=4 ts=4 sts=4:

#include <iostream>
#include <ctime>
#include "BSScheme.hpp"
#include "pnl/pnl_random.h"

int main()
{
    double eurlerError, milshteinError;
    BSEuler euler(2., 0.2, 0.03, 100.);
    BSMilshtein milshtein(2., 0.2, 0.03, 100.);
    PnlRng *rng = pnl_rng_create(PNL_RNG_MERSENNE);
    pnl_rng_sseed(rng, std::time(NULL));




    pnl_rng_free(&rng);
    exit(0);
}
